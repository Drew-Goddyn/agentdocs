module ActiveRecord; end
