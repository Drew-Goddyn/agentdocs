# Active Record Basics

This is the active record basics guide.
