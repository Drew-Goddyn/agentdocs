# Action Controller

This is the action controller guide.
